describe file('/var/log/secure') do
  its('content') { should match(%r{elinks\s.*?http://labgamification.dexter.com.br}) }
end
