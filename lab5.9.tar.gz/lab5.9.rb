describe file('/var/log/secure') do
  its('content') { should match(%r{mkfs.ext4\s.*?\/dev/lab/gamification}) }
end
