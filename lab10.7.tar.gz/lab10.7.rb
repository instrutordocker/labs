describe file('/etc/exports') do
  its('content') { should match(%r{\/empresa\s.*?172.16.1.0\s.*?\(rw)}) }
end
