describe file('/var/log/secure') do
  its('content') { should match(%r{ipa\s.*?user-find\s.*?userlinus}) }
end
