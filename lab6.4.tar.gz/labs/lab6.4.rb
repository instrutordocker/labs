describe command('getent group lab | awk -F\: \'{print $4}\'') do
   its('stdout') { should match 'suporte' }
end
