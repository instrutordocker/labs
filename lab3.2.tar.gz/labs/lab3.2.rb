describe file('/var/log/secure') do
  its('content') { should match(%r{sudo\s.*?ss\s.*?-at\s.*?dport\s.*?=\s.*?:ssh\s.*?or\s.*?sport\s.*?=\s.*?:ssh}) }
end
