describe package('ntpdate') do
  it { should_not be_installed }
end
