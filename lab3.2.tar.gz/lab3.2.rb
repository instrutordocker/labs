describe systemd_service('vsftpd') do
  it { should be_enabled }
end