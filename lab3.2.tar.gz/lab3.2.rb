describe file('/etc/named.conf') do
  its('content') { should match(%r{allow-query\s.*?172.16.100.0}) }
end
