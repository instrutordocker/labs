describe file('/var/log/secure') do
  its('content') { should match(%r{ss\s.*?-tu}) }
end
