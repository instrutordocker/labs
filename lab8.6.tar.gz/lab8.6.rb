describe file('/var/log/secure') do
  its('content') { should match(%r{semanage\s.*?login\s.*?-a\s.*?-s\s.*?user_u\s.*?user-lab}) }
end
