describe package('bind') do
  it { should be_installed }
end
