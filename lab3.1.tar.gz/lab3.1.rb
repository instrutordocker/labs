describe systemd_service('vsftpd') do
  it { should be_installed }
end