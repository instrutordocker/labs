describe package('alien') do
  it { should be_installed }
end
