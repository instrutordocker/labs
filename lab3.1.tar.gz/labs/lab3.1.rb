describe file('/var/log/secure') do
  its('content') { should match(%r{arp\s.*?-n}) }
end
