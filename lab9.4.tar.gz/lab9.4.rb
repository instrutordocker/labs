describe file('/etc/squid/squid.conf') do
  its('content') { should match(%r{http_access\s.*?deny\s.*?lab}) }
end
