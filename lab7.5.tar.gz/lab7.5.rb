describe file('/var/log/secure') do
  its('content') { should match(%r{firewall-cmd\s.*?--zone=public\s.*?--add-service=ftp\s.*?--permanent}) }
end
