describe package('httpd') do
  it { should be_installed }
end
