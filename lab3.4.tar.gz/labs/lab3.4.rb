describe file('/var/log/secure') do
  its('content') { should match(%r{traceroute\s.*?terra.com.br\s.*?-n}) }
end
