describe file('/var/log/secure') do
  its('content') { should match(%r{ldapadd\s.*?-x\s.*?-D\s.*?cn=admin,dc=dexter,dc=com,dc=br\s.*?-f\s.*?\/opt/lab.ldif\s.*?-W}) }
end
