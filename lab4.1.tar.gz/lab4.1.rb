describe package('squid') do
  it { should be_installed }
end
