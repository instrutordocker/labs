describe package('ipa-client') do
  it { should be_installed }
end
