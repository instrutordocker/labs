describe user('devops') do
  it { should exist }
end
