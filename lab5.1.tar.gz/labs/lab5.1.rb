describe file('/etc/exports') do
  its('content') { should match(%r{lab\s.*?ro}) }
end
