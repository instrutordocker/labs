describe file('/var/log/secure') do
  its('content') { should match(%r{iptables\s.*?-P\s.*?OUTPUT\s.*?DROP}) }
end
