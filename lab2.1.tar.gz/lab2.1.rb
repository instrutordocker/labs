describe package('unbound') do
  it { should be_installed }
end
