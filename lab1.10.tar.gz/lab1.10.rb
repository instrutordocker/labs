describe file('/var/log/secure') do
  its('content') { should match(%r{nmap\s.*?172.16.100.210}) }
end
