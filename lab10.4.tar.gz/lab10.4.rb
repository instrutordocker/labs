describe file('/var/log/secure') do
  its('content') { should match(%r{setsebool\s.*?-P\s.*?samba_enable_home_dirs\s.*?on}) }
end
