describe file('/var/log/secure') do
  its('content') { should match(%r{ansible\s.*?local\s.*?-m\s.*?user\s.*?-a\s.*?userlab}) }
end
