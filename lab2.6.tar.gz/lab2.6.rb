describe file('/etc/postfix/main.cf') do
  its('content') { should match(%r{myhostname\s.*?labgamification.dexter.com.br}) }
end
