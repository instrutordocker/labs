describe docker_container('debian') do
  it { should be_running }
end
