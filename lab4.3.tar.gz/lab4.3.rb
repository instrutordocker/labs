describe file('/etc/squid/squid.conf') do
  its('content') { should match(%r{acl\s.*?lab\s.*?dstdomain\s.*?filmesparadownloads.org}) }
end
