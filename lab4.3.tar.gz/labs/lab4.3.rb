describe file('/var/log/secure') do
  its('content') { should match(%r{ipa\s.*?user-add\s.*?userlinus\s.*?--first=User\s.*?--last=Linus\s.*?--password}) }
end
