describe package('samba') do
  it { should be_installed }
end
