describe file('/var/log/secure') do
  its('content') { should match(%r{ldapsearch\s.*?-x\s.*?-LLL\s.*?-b\s.*?ou=usuarios,dc=dexter,dc=com,dc=br\s.*?uid=linus}) }
end
