describe file('/var/log/secure') do
  its('content') { should match(%r{ipa\s.*?group-add\s.*?lab}) }
end
