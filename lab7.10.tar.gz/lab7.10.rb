describe file('/root/.ssh/id_rsa') do
 it { should exist }
end
