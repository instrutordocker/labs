describe file('/var/log/secure') do
  its('content') { should match(%r{firewall-cmd\s.*?--zone=public\s.*?--list-services}) }
end
