describe file('/etc/ansible/ansible.cfg') do
  its('content') { should match(%r{private_key_file\s.*?\/etc/lab/sshkey}) }
end
