describe file('/etc/postfix/main.cf') do
  its('content') { should match(%r{mynetworks\s.*?172.16.100.0}) }
end
