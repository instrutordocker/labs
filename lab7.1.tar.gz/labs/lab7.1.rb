describe package('vsftpd') do
  it { should be_installed }
end
