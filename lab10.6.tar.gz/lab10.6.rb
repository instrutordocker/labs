describe package('nfs-utils') do
  it { should be_installed }
end
