describe file('/var/log/messages') do
  its('content') { should match(%r{uname\s.*?-r}) }
end
