describe file('/etc/postfix/main.cf') do
  its('content') { should match(%r{inet_interfaces\s.*?all}) }
end
