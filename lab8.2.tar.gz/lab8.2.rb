describe file('/etc/sysconfig/selinux') do
  its('content') { should match(%r{SELINUX=enforcing}) }
end
