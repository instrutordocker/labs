describe file('/etc/httpd/conf/httpd.conf') do
  its('content') { should match(%r{ServerSignature\s.*?Off}) }
end
