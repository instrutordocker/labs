describe file('/var/log/secure') do
  its('content') { should match(%r{iptables\s.*?-A\s.*?OUTPUT\s.*?-p\s.*?udp\s.*?-s\s.*?10.0.2.15\s.*?-d\s.*?--dport\s.*?53\s.*?-j\s.*?ACCEPT}) }
end
