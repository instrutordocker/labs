describe file('/etc/sysctl.d/99-sysctl.conf') do
  its('content') { should match(%r{net.ipv4.ip_forward=1}) }
end
