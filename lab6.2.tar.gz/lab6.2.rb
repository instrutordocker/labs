describe file('/var/log/secure') do
  its('content') { should match(%r{setfacl\s.*?-m\s.*?u:user-lab:rw-\s.*?\/empresa/relatorio.txt}) }
end
