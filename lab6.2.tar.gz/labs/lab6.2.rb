describe file('/home/lab') do
  its('group') { should eq 'lab' }
end
