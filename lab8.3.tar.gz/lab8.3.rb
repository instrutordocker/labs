describe file('/etc/httpd/conf.d/lab.conf') do
  its('content') { should match(%r{VirtualHost\s.*?8080}) }
end
