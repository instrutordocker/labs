describe file('/var/log/secure') do
  its('content') { should match(%r{ansible\s.*?local\s.*?-m\s.*?yum\s.*?-a\s.*?htop}) }
end
