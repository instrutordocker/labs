describe file('/var/log/secure') do
  its('content') { should match(%r{cp\s.*?--preserve=context\s.*?\/etc/resolv.conf\s.*?\/tmp}) }
end
