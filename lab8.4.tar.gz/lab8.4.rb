describe file('/etc/httpd/conf.d/lab.conf') do
  its('content') { should match(%r{DocumentRoot\s.*?\/var/www/html/lab}) }
end
