describe file('/var/log/secure') do
  its('content') { should match(%r{mysql_secure_installation}) }
end
