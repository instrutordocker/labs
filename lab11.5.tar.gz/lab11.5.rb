describe service('rsyncd') do
  it { should be_running }
end
