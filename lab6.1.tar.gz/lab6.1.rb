describe file('/var/log/secure') do
  its('content') { should match(%r{setfacl\s.*?-m\s.*?g:group-lab:rwx\s.*?\/empresa}) }
end
