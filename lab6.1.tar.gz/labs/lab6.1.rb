describe file('/etc/samba/smb.conf') do
  its('content') { should match(%r{valid\s.*?users\s.*?lab}) }
end
