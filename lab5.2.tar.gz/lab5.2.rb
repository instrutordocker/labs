describe file('/etc/resolv.conf') do
  its('content') { should match(%r{nameserver\s.*?172.16.1.105}) }
end
