describe file('/var/log/secure') do
  its('content') { should match(%r{setsebool\s.*?-P\s.*?squid_connect_any\s.*?on}) }
end
