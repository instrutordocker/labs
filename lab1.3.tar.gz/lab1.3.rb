describe file('/var/log/secure') do
  its('content') { should match(%r{virsh\s.*?start\s.*?linux-server}) }
end
