describe file('/var/log/secure') do
  its('content') { should match(%r{ldapmodify\s.*?-x\s.*?-D\s.*?cn=admin,dc=dexter,dc=com,dc=br\s.*?-f\s.*?\/opt/modify-lab.ldif\s.*?-W}) }
end
