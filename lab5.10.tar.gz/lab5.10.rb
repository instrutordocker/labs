describe file('/var/log/secure') do
  its('content') { should match(%r{mount\s.*?\/dev/lab/gamification\s.*?\/media}) }
end
