describe command('sysctl -a | grep \'net.ipv4.ip_forward = 1\' | awk -F\' \' \'{print $3}\'') do
   its('stdout') { should match '1' }
end
