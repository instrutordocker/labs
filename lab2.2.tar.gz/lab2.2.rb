describe file('/var/log/secure') do
  its('content') { should match(%r{iptables\s.*?-A\s.*?OUTPUT\s.*?-s\s.*?-d\s.*?127.0.0.1\s.*?-j\s.*?ACCEPT}) }
end
