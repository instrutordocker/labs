describe file('/var/log/secure') do
  its('content') { should match(%r{echo\s.*?lab\s.*?mail\s.*?-s\s.*?lab\s.*?root@dexter.com.br}) }
end
