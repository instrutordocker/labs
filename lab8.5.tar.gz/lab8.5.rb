describe file('/var/log/secure') do
  its('content') { should match(%r{elinks\s.*?lab.dexter.com.br:8080}) }
end
