describe user('suporte') do
  its('group') { should match 'ti' } 
end
