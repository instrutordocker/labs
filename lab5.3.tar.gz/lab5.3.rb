describe file('/var/log/secure') do
  its('content') { should match(%r{mdadm\s.*?-S\s.*?\/dev/md0}) }
end
