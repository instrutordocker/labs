describe file('/var/log/secure') do
  its('content') { should match(%r{ipa-client-install\s.*?--domain=dexter.com.br\s.*?--no-ntp\s.*?--mkhomedir}) }
end
