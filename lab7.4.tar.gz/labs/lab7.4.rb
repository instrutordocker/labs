describe file('/var/log/secure') do
  its('content') { should match(%r{firewall-cmd\s.*?--add-service=ftp}) }
end
