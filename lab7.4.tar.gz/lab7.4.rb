describe file('/etc/aliases') do
  its('content') { should match(%r{lab\s.*?root}) }
end
