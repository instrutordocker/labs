describe file('/var/log/secure') do
  its('content') { should match(%r{mdadm\s.*?--detail\s.*?--scan}) }
end
