describe file('/etc/postfix/main.cf') do
  its('content') { should match(%r{mydomain\s.*?dexter.com.br}) }
end
