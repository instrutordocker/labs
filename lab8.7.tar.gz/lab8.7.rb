describe file('/var/log/secure') do
  its('content') { should match(%r{setsebool\s.*?-P\s.*?ftpd_anon_write\s.*?on}) }
end
