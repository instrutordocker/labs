describe file('/var/log/secure') do
  its('content') { should match(%r{fsck\s.*?\/dev/sda1}) }
end
