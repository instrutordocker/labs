describe file('/etc/unbound/unbound.conf') do
  its('content') { should match(%r{forward-addr\s.*?8.8.4.4}) }
end
