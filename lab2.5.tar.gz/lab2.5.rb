describe file('/var/log/secure') do
  its('content') { should match(%r{iptables\s.*?-t\s.*?nat\s.*?-A\s.*?POSTROUTING\s.*?-o\s.*?enp0s3\s.*?-j\s.*?MASQUERADE}) }
end
