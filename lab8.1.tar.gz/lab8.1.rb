describe package('ntp') do
  it { should be_installed }
end
