describe file('/etc/httpd/conf/httpd.conf') do
  its('content') { should match(%r{Listen\s.*?8080}) }
end
