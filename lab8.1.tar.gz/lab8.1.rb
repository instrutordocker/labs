describe file('/var/log/secure') do
  its('content') { should match(%r{setenforce\s.*?enforcing}) }
end
