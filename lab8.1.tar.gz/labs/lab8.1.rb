describe docker_image('debian') do
  it { should exist }
end
