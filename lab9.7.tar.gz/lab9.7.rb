describe file('/var/log/secure') do
  its('content') { should match(%r{vgcreate\s.*?lab\s.*?\/dev/md0}) }
end
