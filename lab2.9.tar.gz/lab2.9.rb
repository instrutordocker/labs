describe file('/etc/postfix/main.cf') do
  its('content') { should match(%r{inet_protocols\s.*?ipv4}) }
end
