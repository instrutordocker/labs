describe file('/opt/pacotes/sl-3.03-18.x86_64.rpm') do
 it { should exist }
end
