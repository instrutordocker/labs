describe file('/var/www/html/index.html') do
  its('content') { should match(%r{Lab\s.*?Gamification}) }
end
