describe file('/etc/vsftpd/vsftpd.conf') do
  its('content') { should match(%r{chroot\_local\_user=YES}) }
end
