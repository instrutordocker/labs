describe file('/var/log/secure') do
  its('content') { should match(%r{cat\s.*?\/var/spool/mail/root}) }
end
