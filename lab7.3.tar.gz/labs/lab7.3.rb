describe file('/etc/vsftpd/vsftpd.conf') do
  its('content') { should match(%r{anonymous_enable=NO\s.*?chroot_local_user=YES\s.*?listen=YES}) }
end
