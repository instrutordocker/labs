describe file('/etc/ansible/hosts') do
  its('content') { should match(%r{lab\s.*?172.16.100.210}) }
end
