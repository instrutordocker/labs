describe file('/etc/postfix/main.cf') do
  its('content') { should match(%r{relayhost\s.*?mail.4linux.com.br}) }
end
