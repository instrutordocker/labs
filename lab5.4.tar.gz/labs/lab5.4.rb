describe file('/var/log/secure') do
  its('content') { should match(%r{semanage\s.*?fcontext\s.*?-a\s.*?-t\s.*?public_content_rw_t\s.*?\/lab}) }
end
