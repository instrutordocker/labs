describe file('/etc/unbound/unbound.conf') do
  its('content') { should match(%r{iccess-control\s.*?172.16.1.0}) }
end
