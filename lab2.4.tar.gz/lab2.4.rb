describe file('/var/log/secure') do
  its('content') { should match(%r{iptables\s.*?-A\s.*?OUTPUT\s.*?-p\s.*?tcp\s.*?-s\s.*?10.0.2.15\s.*?-d\s.*?--dport\s.*?80\s.*?-j\s.*?ACCEPT}) }
end
