describe file('/var/log/secure') do
  its('content') { should match(%r{semodule\s.*?-i\s.*?lab.pp}) }
end
