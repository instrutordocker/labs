describe file('/var/log/secure') do
  its('content') { should match(%r{sar\s.*?-u\s.*?5\s.*?5}) }
end
