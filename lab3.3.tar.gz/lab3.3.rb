describe systemd_service('lftp') do
  it { should be_installed }
end