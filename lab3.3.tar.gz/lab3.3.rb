describe package('lftp') do
  it { should be_installed }
end
