describe file('/var/log/secure') do
  its('content') { should match(%r{nmap\s.*?-o\s.*?100-5000\s.*?localhost}) }
end
