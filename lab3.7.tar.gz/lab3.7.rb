describe systemd_service('httpd') do
  it { should be_enabled }
end