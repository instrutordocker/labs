describe file('/var/log/secure') do
  its('content') { should match(%r{tcpdump\s.*?-i\s.*?enp0s8\s.*?port\s.*?22}) }
end
