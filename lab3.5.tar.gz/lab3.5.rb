describe file('/var/log/secure') do
  its('content') { should match(%r{lftp\s.*?anonymous\s.*?/@\s.*?172.16.1.120}) }
end
