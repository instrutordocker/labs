describe file('/var/log/secure') do
  its('content') { should match(%r{dig\s.*?172.16.100.210\s.*?terra.com.br}) }
end
